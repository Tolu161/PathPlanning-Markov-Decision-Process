%%20042059
%%%Policygridworld 
%COMP 3004 COURSEWORK 
function PolicyIterationGridworld()
    % Initial setup and world configuration
    set(0,'DefaultAxesFontSize',18);
    format compact;
    pauseOn = false; 
    %World = [1 1 1 1 ...]; % Continue initializing your World matrix
   %this world is asymmetrical, so it can be used to talk about POMDPS

    World = [  
        1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1
        1 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 
        1 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
        1 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
        1 0 0 0 0 1 1 1 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 1 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 0 1 1 1 1 1 1 1 1 1 1 1 1 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 1 1 1 1 0 0 0 0 1
        1 0 0 0 1 1 1 0 0 0 0 0 0 1 1 1 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 0 0 1
        1 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
        1 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
        1 0 0 0 1 1 1 1 1 1 0 0 0 0 0 0 0 0 0 1 1 1 1 1 1 1 1 0 0 0 0 1 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1
        1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1]; 



    %{
World = [
        1 1 1 1 1 1 1 1 1 1 1 1
        1 1 1 0 0 0 0 0 0 0 1 1
        1 0 1 0 0 0 0 0 0 1 0 1
        1 0 0 0 1 1 1 0 0 1 0 1
        1 0 0 0 1 1 1 0 0 1 0 1 
        1 0 0 0 0 0 0 0 0 0 0 1
        1 1 1 0 0 0 0 0 0 0 0 1 
        1 1 0 0 1 0 0 0 0 0 0 1
        1 0 0 1 1 0 0 1 1 1 0 1
        1 0 0 0 0 0 0 1 1 0 0 1 
        1 0 0 0 0 0 0 1 1 0 0 1
        1 1 1 1 1 1 1 1 1 1 1 1]; 

    %}

    [rewardFunction, transitionProbabilities, stateIndex] = initializeWorld(World);
    gamma = 0.95;
    tol = 1e-3;
    numStates = numel(stateIndex);
    policy = randi(4, numStates, 1);
    values = zeros(numStates, 1);

    % Tracking variables for plots
    iterationTimes = [];
    totalRewards = [];
    cumulativeReward = 0;


        % Setup rewards
    rewardFunction = -0.04 * ones(size(World)); % Small penalty for non-goal states
    rewardFunction(World == 1) = -1; % Large penalty for obstacles
    
    % High reward for goal state, you can adjust the goal location as needed
    goalPosition = sub2ind(size(World), 12, 49); % Example: goal at (6,49)% rectangle map 
    %goalPosition = sub2ind(size(World), 4, 11); %square map

    rewardFunction(goalPosition) = 100;
    
    % Optional: Intermediate rewards for checkpoints
    %checkpoints = [sub2ind(size(World), 6, 44), sub2ind(size(World), 8, 35)]; % Example checkpoints rectangle map
    %checkpoints = sub2ind(size(World), 7, 6); %square map
    %checkpoints = sub2ind(size(World), 4, 8);
    %rewardFunction(checkpoints) = 0.5; % Intermediate rewards


    % Iteration controls
    isPolicyStable = false;
    iterations = 0;
    maxIterations = 300;  % Maximum number of iterations

    % Initialize visualization figure
    policyFigure = figure('Name', 'Policy Visualization', 'NumberTitle', 'off');
    set(policyFigure, 'units', 'normalized', 'outerposition', [0 0 1 1]);

    % Main policy iteration loop
    while ~isPolicyStable && iterations < maxIterations
        tic;
        iterations = iterations + 1;
        % Policy Evaluation
        values = policyEvaluation(policy, values, rewardFunction, transitionProbabilities, gamma);
        
        % Policy Improvement
        [policy, isPolicyStable] = policyImprovement(policy, values, transitionProbabilities, rewardFunction, gamma);
        
        % Tracking time and rewards
        iterationTimes(end+1) = toc;
        cumulativeReward = sum(rewardFunction(stateIndex) .* values);
        totalRewards(end+1) = cumulativeReward;

        % Update visualization of the policy within the same figure
        visualizePolicy(World, policy, stateIndex, values, policyFigure);

    end
    
    % Calculate total elapsed time
    elapsedTime = sum(iterationTimes);
    fprintf('Policy Iteration converged in %d iterations with elapsed time: %.2f seconds.\n', iterations, elapsedTime);
    disp(['Policy stable after ', num2str(iterations), ' iterations.']);
    
    % Plotting and results visualization
    plotResults(World, values, iterationTimes, totalRewards);
end





function visualizePolicy(World, policy, stateIndex, values, policyFigure)
    figure(policyFigure);  % Activate the figure for updating
    clf;  % Clear the figure for fresh plotting

    [rows, cols] = size(World);
    [X, Y] = meshgrid(1:cols, 1:rows);

    U = zeros(size(World)); % Horizontal components of the arrows
    V = zeros(size(World)); % Vertical components of the arrows

    for i = 1:length(policy)
        [y, x] = ind2sub([rows, cols], stateIndex(i));
        switch policy(i)
            case 1  % Up
                V(y, x) = -1;
            case 2  % Right
                U(y, x) = 1;
            case 3  % Down
                V(y, x) = 1;
            case 4  % Left
                U(y, x) = -1;
        end
    end

    % Create a full grid of NaNs and then populate the free space indices with values
    fullValueGrid = NaN(size(World));
    fullValueGrid(stateIndex) = values;

    imagesc(fullValueGrid); % Display values as a heatmap
    colormap('spring'); % Set to a cooler color spectrum
    %colormap("parula");
    colorbar;
    axis image;  % Ensure consistent aspect ratio
    title('Value Function');

    hold on;
    quiver(X, Y, U, V, 0.5, 'k', 'MaxHeadSize', 2, 'AutoScale', 'off');
    %scatter(X(World==1), Y(World==1), 'ks', 'filled'); % Black filled squares for obstacles

    % Fill obstacles with black color
    for i = 1:numel(X)
        if World(i) == 1
            rectangle('Position', [X(i)-0.5, Y(i)-0.5, 1, 1], 'FaceColor', 'k', 'EdgeColor', 'k');
        end
    end


    set(gca, 'XTick', [], 'YTick', []);
    title('Policy Visualization with Heatmap and Obstacles');
    drawnow;  % Ensure the plot updates are rendered immediately
end



function plotResults(World, values, iterationTimes, totalRewards)
    % This function updates plots for results at the end of iterations
    % This function creates a figure with multiple subplots to show different aspects of the policy iteration results.

    f1 = figure('Name', 'Iteration Results', 'NumberTitle', 'off');
    set(f1, 'units', 'normalized', 'outerposition', [0 0 1 1]);

    % World colormap
    subplot(2, 2, 1);
    imagesc(~World);  % Visualize the world as binary, where 1s might be obstacles
    colormap(gray);
    axis equal tight;
    title('World Map');

    % Value function heatmap
    subplot(2, 2, 2);
    fullValueGrid = NaN(size(World)); % Initialize with NaN for obstacles
    fullValueGrid(World == 0) = values; % Fill in values only for free states
    imagesc(fullValueGrid);
    colormap("bone");
    colorbar;
    axis equal tight;
    title('Value Function');

    % Time per iteration
    subplot(2, 2, 3);
    plot(iterationTimes, 'LineWidth', 2);
    title('Time per Iteration');
    xlabel('Iteration');
    ylabel('Time (seconds)');
    grid on;

    % Cumulative rewards
    subplot(2, 2, 4);
    plot(cumsum(totalRewards), 'LineWidth', 2);
    title('Cumulative Reward Collected Over Iterations');
    xlabel('Iteration');
    ylabel('Cumulative Reward');
    grid on;


    % Total computation time
    subplot(2, 3, 5);
    totalComputationTime = cumsum(iterationTimes);
    plot(totalComputationTime, 'LineWidth', 2);
    title('Total Computation Time');
    xlabel('Iteration');
    ylabel('Cumulative Time (seconds)');
    grid on;





    % Ensure figures are updated
    drawnow;
end




%{
function [rewardFunction, transitionProbabilities] = initializeWorld(World)
    % Calculate the dimensions of the World array
    [rows, cols] = size(World);

    % Initialize the reward function with small penalties for open spaces and large penalties for obstacles
    rewardFunction = -0.04 * ones(rows, cols); % small penalty for non-goal states
    rewardFunction(World == 1) = -1; % large penalty for obstacles

    % Define the goal position and assign a high reward
    goalPosition = sub2ind([rows, cols], 6, 49);
    rewardFunction(goalPosition) = 1;  % high reward for the goal state

    % Initialize transition probabilities
    transitionProbabilities = cell(rows * cols, 4);
    
    for r = 1:rows
        for c = 1:cols
            idx = sub2ind([rows, cols], r, c);
            if World(r, c) == 0 % Define transitions only for free spaces
                % Each action has a default low probability of unintended moves
                unintended = 0.05;  % 5% chance of slipping to side directions
                % Calculate valid movements
                for action = 1:4
                    transitions = zeros(rows, cols);
                    % Main direction with high probability
                    switch action
                        case 1 % Up
                            main = [max(r-1, 1), c];
                        case 2 % Down
                            main = [min(r+1, rows), c];
                        case 3 % Left
                            main = [r, max(c-1, 1)];
                        case 4 % Right
                            main = [r, min(c+1, cols)];
                    end
                    transitions(main(1), main(2)) = 1 - 2 * unintended;  % Main move
                    
                    % Side movements
                    if action == 1 || action == 2  % Up or Down
                        side1 = [r, max(c-1, 1)];  % Left side
                        side2 = [r, min(c+1, cols)];  % Right side
                    else  % Left or Right
                        side1 = [max(r-1, 1), c];  % Up side
                        side2 = [min(r+1, rows), c];  % Down side
                    end
                    transitions(side1(1), side1(2)) = unintended;
                    transitions(side2(1), side2(2)) = unintended;
                    
                    % Store the probabilities in a linear index format for easier use later
                    transitionProbabilities{idx, action} = transitions(:)';
                end
            end
        end
    end
end 
%}

%initialise world without obstacle avoidance this one works 

%{

function [rewardFunction, transitionProbabilities, stateIndex] = initializeWorld(World)
    
    [rows, cols] = size(World);
    numFreeStates = sum(World(:) == 0);  % Only free states

    rewardFunction = -0.04 * ones(rows, cols); % Small penalty for non-goal states
    rewardFunction(World == 1) = -1;           % Large penalty for obstacles
    goalPosition = sub2ind([rows, cols], 6, 49); % rectangular map 
    %goalPosition = sub2ind([rows, cols], 10, 10); %square map 
    rewardFunction(goalPosition) = 100;          % High reward for the goal state

    % Initialize transition probabilities
    %transitionProbabilities = cell(rows * cols, 4);

    %newly adjusted line 
    transitionProbabilities = cell(numFreeStates, 4);  % Adjusted to numFreeStates
    stateIndex = find(World == 0);  % Indexes of free states


    for i = 1:numFreeStates
        [r, c] = ind2sub([rows, cols], stateIndex(i));
        
        for action = 1:4
            transitions = zeros(rows, cols);
            
            % Determine the main direction based on action
            switch action
                case 1 % Up
                    main = [max(r-1, 1), c];
                case 2 % Down
                    main = [min(r+1, rows), c];
                case 3 % Left
                    main = [r, max(c-1, 1)];
                case 4 % Right
                    main = [r, min(c+1, cols)];
            end
            
            unintended = 0.05;  % Probability of unintentional movement
            if World(main(1), main(2)) == 0 % Ensure the main move is to a free space
                transitions(main(1), main(2)) = 1 - 2 * unintended;
            end
            
            % Calculate side movements
            if action == 1 || action == 2  % Vertical movement
                side1 = [r, max(c-1, 1)];    % Left side
                side2 = [r, min(c+1, cols)]; % Right side
            else  % Horizontal movement
                side1 = [max(r-1, 1), c];    % Upper side
                side2 = [min(r+1, rows), c]; % Lower side
            end
            
            % Ensure side moves are to free spaces and add unintended probabilities
            if World(side1(1), side1(2)) == 0
                transitions(side1(1), side1(2)) = transitions(side1(1), side1(2)) + unintended;
            end
            if World(side2(1), side2(2)) == 0
                transitions(side2(1), side2(2)) = transitions(side2(1), side2(2)) + unintended;
            end
          

            % Normalize the probabilities to ensure they sum to 1
            probSum = sum(transitions(:));
            if probSum > 0
                transitions = transitions / probSum;
            end
            
            % Store only transitions from free states
            transitionProbabilities{i, action} = transitions(:)'; %new 
            
            %transitionProbabilities{i, action} = transitions(stateIndex); % Transitions vector for each free state
            
            %transitions = applyBoundariesAndObstacles(transitions, World, r, c);%new 
            %transitionProbabilities{i, action} = normalizeTransitions(transitions);%new 

        end
    end
end
%}



function [rewardFunction, transitionProbabilities, stateIndex] = initializeWorld(World)
    [rows, cols] = size(World);
    stateIndex = find(World == 0);  % Indices of free states
    numFreeStates = numel(stateIndex);  % Number of free states
    
    rewardFunction = -0.04 * ones(rows, cols);  % Penalty for non-goal states
    rewardFunction(World == 1) = -1;  % Penalty for obstacles
    goalPosition = sub2ind([rows, cols], 12, 49);
    %goalPosition = sub2ind([rows, cols], 4, 11);
    rewardFunction(goalPosition) = 100;  % Reward for goal state

    transitionProbabilities = cell(numFreeStates, 4);  % Transition probabilities for each action in each free state

    % Adjust transition matrix for valid moves
    for i = 1:numFreeStates
        [r, c] = ind2sub([rows, cols], stateIndex(i));
        for action = 1:4
            transitions = zeros(numFreeStates, 1);  % Transition probabilities for free states only
            
            % Determine the target cell based on action
            directions = [0 -1; 0 1; -1 0; 1 0];  % [Up, Down, Left, Right]
            targetR = r + directions(action, 1);
            targetC = c + directions(action, 2);

            if targetR > 0 && targetR <= rows && targetC > 0 && targetC <= cols && World(targetR, targetC) == 0
                targetIdx = find(stateIndex == sub2ind([rows, cols], targetR, targetC));
                transitions(targetIdx) = 0.8;  % Main intended move probability
            else
                transitions(i) = transitions(i) + 0.8;  % Redirect to current state if move invalid
            end

            % Unintended moves to adjacent cells
            for adj = [1 -1 0 0; 0 0 1 -1]'  % Adjustments for adjacent cells
                adjR = r + adj(1);
                adjC = c + adj(2);
                if adjR > 0 && adjR <= rows && adjC > 0 && adjC <= cols && World(adjR, adjC) == 0
                    adjIdx = find(stateIndex == sub2ind([rows, cols], adjR, adjC));
                    transitions(adjIdx) = transitions(adjIdx) + 0.05;
                else
                    transitions(i) = transitions(i) + 0.05;  % Stay in place if adjacent move invalid
                end
            end

            % Normalize probabilities
            transitions = transitions / sum(transitions);
            transitionProbabilities{i, action} = transitions;
        end
    end
end




    %{
    for r = 1:rows
        for c = 1:cols
            idx = sub2ind([rows, cols], r, c);
            if World(r, c) == 0 % Define transitions only for free spaces
                for action = 1:4
                    transitions = zeros(rows, cols);
                    switch action
                        case 1 % Up
                            main = [max(r-1, 1), c];
                        case 2 % Down
                            main = [min(r+1, rows), c];
                        case 3 % Left
                            main = [r, max(c-1, 1)];
                        case 4 % Right
                            main = [r, min(c+1, cols)];
                    end
                    unintended = 0.05;  % Chance of slipping to side directions
                    % Set main direction move probability
                    transitions(main(1), main(2)) = 1 - 2 * unintended;
                    % Side movements probabilities
                    if action == 1 || action == 2  % Up or Down
                        side1 = [r, max(c-1, 1)];  % Left side
                        side2 = [r, min(c+1, cols)];  % Right side
                    else  % Left or Right
                        side1 = [max(r-1, 1), c];  % Up side
                        side2 = [min(r+1, rows), c];  % Down side
                    end
                    %transitions(side1(1), side1(2)) += unintended;
                    transitions(side1(1), side1(2)) = transitions(side1(1), side1(2)) + unintended;
                    %transitions(side2(1), side2(2)) += unintended;
                    transitions(side2(1), side2(2)) = transitions(side2(1), side2(2)) + unintended;

                    % Normalize the probabilities to ensure they sum to 1
                    probSum = sum(transitions(:));
                    if probSum > 0  % Avoid division by zero
                        transitions = transitions / probSum;
                    end

                    transitionProbabilities{idx, action} = transitions(:)';
                end
            else
                % For obstacles, ensure no movement is possible
                for action = 1:4
                    transitionProbabilities{idx, action} = zeros(rows * cols, 1)';
                end
            end
        end
    end
end
%}



function probabilities = defineTransitions(r, c, dRow, dCol, rows, cols)
    transitions = zeros(rows, cols);
    mainRow = max(1, min(rows, r + dRow));
    mainCol = max(1, min(cols, c + dCol));
    transitions(mainRow, mainCol) = 0.8;  % High probability for intended movement

    % Consider edge cases where movement is off the bounds
    if mainRow ~= r + dRow || mainCol ~= c + dCol
        transitions(r, c) = 0.2;  % Stay in place if movement is blocked by grid bounds
    else
        % Adding small probabilities for slipping to adjacent cells
        adjacentPositions = [
            r, max(1, c - 1);       % Left
            r, min(cols, c + 1);    % Right
            max(1, r - 1), c;       % Up
            min(rows, r + 1), c     % Down
        ];
        for i = 1:size(adjacentPositions, 1)
            if ~(adjacentPositions(i, 1) == mainRow && adjacentPositions(i, 2) == mainCol)
                transitions(adjacentPositions(i, 1), adjacentPositions(i, 2)) = 0.05;
            end
        end
    end

    probabilities = transitions(:)';
end

%V1 

function values = policyEvaluation(policy, values, rewardFunction, transitionProbabilities, gamma, World)
    threshold = 1e-3;
    
    while true
        delta = 0;
        for s = 1:numel(values)
            v = values(s);
            a = policy(s);
            %recently added change : 
            P = reshape(transitionProbabilities{s, a}, [], 1);  % make it a column vector if not already
            % Debugging: Check sizes of P and values
            disp(['Size of P: ', num2str(size(P))]);
            disp(['Size of values: ', num2str(size(values))]);

            values(s) = rewardFunction(s) + gamma * sum(P .* values);
            delta = max(delta, abs(v - values(s)));
        end
        if delta < threshold
            break; %break if chnages are below the threshold
        end
    end
end





function [policy, isPolicyStable] = policyImprovement(policy, values, transitionProbabilities, rewardFunction, gamma)
    isPolicyStable = true;
    for s = 1:numel(policy)
        oldAction = policy(s);
        [maxValue, bestAction] = max(arrayfun(@(a) sum(transitionProbabilities{s, a} .* (rewardFunction(s) + gamma * values)), 1:size(transitionProbabilities, 2)));
        policy(s) = bestAction;
        if oldAction ~= bestAction
            isPolicyStable = false;
        end
    end
end
%{
function visualizePolicy(World, policy, stateIndex)
    [rows, cols] = size(World);
    [DX, DY] = deal(zeros(rows, cols));
    for s = 1:length(policy)
        [y, x] = ind2sub([rows, cols], stateIndex(s));
        switch policy(s)
            case 1, [DX(y, x), DY(y, x)] = deal(0, -1);  % North
            case 2, [DX(y, x), DY(y, x)] = deal(1, -1);   % Northeast
            case 3, [DX(y, x), DY(y, x)] = deal(1, 0);    % East
            case 4, [DX(y, x), DY(y, x)] = deal(1, 1);    % Southeast
            case 5, [DX(y, x), DY(y, x)] = deal(0, 1);    % South
            case 6, [DX(y, x), DY(y, x)] = deal(-1, 1);   % Southwest
            case 7, [DX(y, x), DY(y, x)] = deal(-1, 0);   % West
            case 8, [DX(y, x), DY(y, x)] = deal(-1, -1);  % Northwest
        end
    end
    quiver(DX, DY, 'k');
    title('Policy Visualization');
    axis equal tight;
    set(gca, 'XTick', [], 'YTick', []);
    drawnow;
end
%}

%{
function visualizePolicy(World, policy, stateIndex, values)
    [rows, cols] = size(World);
    [X, Y] = meshgrid(1:cols, 1:rows);

    U = zeros(size(World)); % Horizontal components of the arrows
    V = zeros(size(World)); % Vertical components of the arrows

    for i = 1:length(policy)
        [y, x] = ind2sub([rows, cols], stateIndex(i));
        switch policy(i)
            case 1  % Up
                V(y, x) = -1;
            case 2  % Right
                U(y, x) = 1;
            case 3  % Down
                V(y, x) = 1;
            case 4  % Left
                U(y, x) = -1;
        end
    end

    figure;
    h = imagesc(values); % Display values as a heatmap
    hold on;
    colormap('cool'); % Set to a cooler color spectrum
    set(h, 'AlphaData', ~isnan(values)); % Set transparency to ignore NaNs

    % Correcting the position and size of the arrows
    quiver(X, Y, U, V, 0.5, 'w', 'MaxHeadSize', 2, 'AutoScale', 'off');

    % Plotting obstacles on top
    [obsY, obsX] = find(World == 1);
    scatter(obsX, obsY, 'ks', 'filled'); % Black filled squares for obstacles

    hold off;
    colorbar;
    axis equal tight;
    set(gca, 'XTick', [], 'YTick', []);
    grid on; % Enable grid to check alignment
    title('Policy Visualization with Heatmap and Obstacles');
end
%}










